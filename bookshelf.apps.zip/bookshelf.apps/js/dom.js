const UNCOMPLETED_LIST_BOOKSHELF_ID = "books";
const COMPLETED_LIST_BOOKSHELF_ID = "completed-books";
const BOOKSHELF_ITEMID = "itemId";
 
function makeBookshelf(data, author, year, isCompleted) {

    const textTitle = document.createElement("h2");
    textTitle.innerText = data;
 
    const textAuthor = document.createElement("h4");
    textAuthor.innerText = author;
 
    const textYear = document.createElement("p");
    textYear.innerText = year;
 
    const textContainer = document.createElement("div");
    textContainer.classList.add("inner")
    textContainer.append(textTitle, textAuthor, textYear);
 
    const container = document.createElement("div");
    container.classList.add("inner")
    container.append(textContainer);
 
    if (isCompleted) { 
        container.append(
            createUndoButton(),
            createTrashButton()
        );
    } else {
        container.append(
            createCheckButton(),
            createDeleteButton()
        );
    }
 
    return container;
}
 
function createUndoButton() {
    return createButton("undo-button", function (event) {
        undoTitleFromCompleted(event.target.parentElement);
    });
}
 
function createTrashButton() {
    return createButton("trash-button", function (event) {
        removeTitleFromCompleted(event.target.parentElement);
    });
}

function createDeleteButton() {
    return createButton("delete-button", function (event) {
        removeTitleFromBookshelf(event.target.parentElement);
    });
}

 
function createCheckButton() {
    return createButton("check-button", function (event) {
        addTitleToCompleted(event.target.parentElement);
    });
}
 
function createButton(buttonTypeClass, eventListener) {
    const button = document.createElement("button");
    button.classList.add(buttonTypeClass);
    button.addEventListener("click", function (event) {
        eventListener(event);
        event.stopPropagation();
    });
    return button;
}
 
function addBookshelf() {
    const uncompletedBOOKSHELFList = document.getElementById(UNCOMPLETED_LIST_BOOKSHELF_ID);
    const textBookshelf = document.getElementById("title").value;
    const textAuthor = document.getElementById("date").value;
    const year = document.getElementById("year").value;
 
    const bookshelf = makeBookshelf(textBookshelf, textAuthor, year, false);
    const bookshelfObject = composeBookshelfObject(textBookshelf, textAuthor, year, false);
 
    bookshelf[BOOKSHELF_ITEMID] = bookshelfObject.id;
    books.push(bookshelfObject);
 
    uncompletedBOOKSHELFList.append(bookshelf);
    updateDataToStorage(alert ("data berhasil disimpan"));
}

function removeTitleFromBookshelf(titleElement) {

    const bookshelfPosition = findBookshelfIndex(titleElement[BOOKSHELF_ITEMID]);
    books.splice(bookshelfPosition, 1);

    titleElement.remove(alert ("data telah dihapus"));
    updateDataToStorage();
}


function addTitleToCompleted(titleElement) {
    const listCompleted = document.getElementById(COMPLETED_LIST_BOOKSHELF_ID);
    const titleTitle = titleElement.querySelector(".inner h2").innerText;
    const titleAuthor = titleElement.querySelector(".inner h4").innerText;
    const titleYear = titleElement.querySelector(".inner p").innerText;

    const newBookshelf = makeBookshelf(titleTitle, titleAuthor, titleYear, true);
    

    const bookshelf = findBookshelf(titleElement[BOOKSHELF_ITEMID]);
    bookshelf.isCompleted = true;
    newBookshelf[BOOKSHELF_ITEMID] = bookshelf.id;

    listCompleted.append(newBookshelf);
    titleElement.remove();

    updateDataToStorage(alert ("data berhasil disimpan"));
}

function removeTitleFromCompleted(titleElement) {

    const bookshelfPosition = findBookshelfIndex(titleElement[BOOKSHELF_ITEMID]);
    books.splice(bookshelfPosition, 1);

    titleElement.remove(alert ("data telah dihapus"));
    updateDataToStorage();
}

function undoTitleFromCompleted(titleElement) {
    const listUncompleted = document.getElementById(UNCOMPLETED_LIST_BOOKSHELF_ID);
    const titleTitle = titleElement.querySelector(".inner h2").innerText;
    const titleAuthor = titleElement.querySelector(".inner h4").innerText;
    const titleYear = titleElement.querySelector(".inner p").innerText;
    
    const newBookshelf = makeBookshelf(titleTitle, titleAuthor, titleYear, false);

    const bookshelf = findBookshelf(titleElement[BOOKSHELF_ITEMID]);
    bookshelf.isCompleted = false;
    newBookshelf[BOOKSHELF_ITEMID] = bookshelf.id;

    listUncompleted.append(newBookshelf);
    titleElement.remove();
    
    updateDataToStorage();
}

function refreshDataFromBooks() {
    const listUncompleted = document.getElementById(UNCOMPLETED_LIST_BOOKSHELF_ID);
    let listCompleted = document.getElementById(COMPLETED_LIST_BOOKSHELF_ID);

    for(bookshelf of books){
        const newBookshelf = makeBookshelf(bookshelf.title, bookshelf.author, bookshelf.year, bookshelf.isCompleted);
        newBookshelf[BOOKSHELF_ITEMID] = bookshelf.id;

        if(bookshelf.isCompleted){
            listCompleted.append(newBookshelf);
        } else {
            listUncompleted.append(newBookshelf);
        }
    }
}
const input=document.getElementById("form");

input.addEventListener("submit", search)

function search(){
    const filter=input.value.toLowerCase();
    const container=document.querySelectorAll("inner");
    console.log(filter)
    for(let i=0; i<container.length; i++){
        const textContainer=container[i].querySelector("inner h2");
        for(let j=0; j<textContainer.length; j++){
            const h2=textContainer[j].querySelectorAll("h2")[0];
            let text=h2.innerText;
            if(text.toLowerCase().indexOf(filter) > -1){
                container[i].style.display="";
            }else{
                container[i].style.display="none"; 
            }
        }
    }
}
