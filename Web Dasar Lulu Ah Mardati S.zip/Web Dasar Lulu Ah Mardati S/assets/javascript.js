const firstName = prompt("Siapa nama kamu?");
const lastName = prompt("Asal?");
const language = prompt("Bisa berbahasa apa?");
 
const user = {
   name: {
       first: firstName,
       last: lastName,
   },
   language: language
};
 
if (user.language === "English") {
   alert("Nice to meet you " + user.name.first + " " + user.name.last + "!");
} else if (user.language === "French") {
   alert("Ravi de vous rencontrer " + user.name.first + " " + user.name.last + "!");
} else if (user.language === "Japanese") {
   alert("Hajimemashite, " + user.name.first + " " + user.name.last + "!");
} else {
   alert("Senang bertemu dengan Anda " + user.name.first + " " + user.name.last + "!");
}
let myArray = [firstName, lastName, language, "Data Pembaca"];

for(const arrayItem of myArray) {
    console.log(arrayItem)
}
console.log("Panjang nilai myArray adalah " + myArray.length + ".")
